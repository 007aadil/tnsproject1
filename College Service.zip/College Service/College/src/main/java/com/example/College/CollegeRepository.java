package com.example.College;
import com.example.College.College;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
public interface CollegeRepository extends JpaRepository<College, Long> {

}
